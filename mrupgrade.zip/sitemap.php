﻿<?php

require_once __DIR__ . '/config/db.php';

header('Content-Type: application/xml; charset=utf-8');

$base = 'https://mrupgrade.mmuhub.com';
$today = date('Y-m-d');

echo '<?xml version="1.0" encoding="UTF-8"?>';
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

$static_pages = array(
    array('url' => '/',                    'priority' => '1.0',  'freq' => 'daily'),
    array('url' => '/shop',      'priority' => '0.9',  'freq' => 'daily'),
    array('url' => '/installment','priority'=> '0.8',  'freq' => 'weekly'),
    array('url' => '/about',     'priority' => '0.6',  'freq' => 'monthly'),
    array('url' => '/store',     'priority' => '0.6',  'freq' => 'monthly'),
    array('url' => '/contact',   'priority' => '0.5',  'freq' => 'monthly'),
);
foreach ($static_pages as $page) {
    echo '<url>';
    echo '<loc>' . $base . $page['url'] . '</loc>';
    echo '<lastmod>' . $today . '</lastmod>';
    echo '<changefreq>' . $page['freq'] . '</changefreq>';
    echo '<priority>' . $page['priority'] . '</priority>';
    echo '</url>';
}

$products = $conn->query("SELECT slug, name, updated_at FROM products WHERE is_active=1 ORDER BY created_at DESC");
while ($p = $products->fetch_assoc()) {
    echo '<url>';
    echo '<loc>' . $base . '/product/' . urlencode($p['slug']) . '</loc>';
    echo '<lastmod>' . date('Y-m-d', strtotime($p['updated_at'] ?? 'now')) . '</lastmod>';
    echo '<changefreq>weekly</changefreq>';
    echo '<priority>0.8</priority>';
    echo '</url>';
}

$cats = $conn->query("SELECT slug, name FROM categories ORDER BY id");
while ($c = $cats->fetch_assoc()) {
    echo '<url>';
    echo '<loc>' . $base . '/shop?cat=' . urlencode($c['slug']) . '</loc>';
    echo '<lastmod>' . $today . '</lastmod>';
    echo '<changefreq>weekly</changefreq>';
    echo '<priority>0.7</priority>';
    echo '</url>';
}

echo '</urlset>';
